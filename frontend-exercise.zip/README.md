To install type "npm install" then "npm start" from the project root directory.


Project created for Hospital IQ Frontend Developer Test by Brandon Wells @ 4-25-17.
